package com.example.pfase

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
