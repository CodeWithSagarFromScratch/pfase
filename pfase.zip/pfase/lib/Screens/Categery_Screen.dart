import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'DrawerMenuItom_List_Screen.dart';
import 'MyCourcesPage_Screen.dart';
import 'SubCategorypage.dart';

class CatageryScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: HomePage(),
      routes: {
        '/offlineCourses': (context) => SubCategoryPage(),
        // '/offlineCourses': (context) => TabExample(),
        // '/onlineCourses': (context) => VideoScreen(),
        '/onlineCourses': (context) => SubCategoryPage(),
      },
    );
  }
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _currentIndex = 0;

  final List<Widget> _children = [
    HomePageContent(),
    CourseCard(
      percentageComplete: 50,
    ),
  ];

  void onTabTapped(int index) {
    setState(() {
      _currentIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Column(
            children: [
              Container(
                height: MediaQuery.of(context).padding.top +
                    kToolbarHeight, // Height of status bar + app bar
                color: Colors.indigo, // Change color as needed
              ),
              Expanded(
                child: _children[_currentIndex],
              ),
              BottomNavigationBar(
                currentIndex: _currentIndex,
                selectedItemColor: Colors.deepOrange,
                onTap: onTabTapped,
                items: <BottomNavigationBarItem>[
                  BottomNavigationBarItem(
                    icon: Icon(Icons.home),
                    label: 'Home',
                  ),
                  BottomNavigationBarItem(
                    icon: Icon(Icons.book),
                    label: 'My Courses',
                  ),
                ],
              ),
            ],
          ),
          Positioned(
            top: MediaQuery.of(context)
                .padding
                .top, // Adjust according to status bar height
            left: 0,
            right: 0,
            child: Container(
              height: kToolbarHeight,
              decoration: BoxDecoration(
                color: Colors.indigo, // Change color as needed
                boxShadow: [
                  BoxShadow(
                    color: Colors.black26,
                    offset: Offset(0, 2),
                    blurRadius: 4.0,
                  ),
                ],
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  IconButton(
                    icon: Icon(Icons.account_circle),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => DrawerMenuItom()),
                      );
                    },
                    color: Colors.white,
                  ),
                  Text(
                    'Select Category',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  Row(
                    children: [
                      IconButton(
                        icon: Icon(Icons.search),
                        onPressed: () {
                          // Handle search action
                        },
                        color: Colors.white,
                      ),
                      IconButton(
                        icon: Icon(Icons.notifications),
                        onPressed: () {
                          // Handle notification action
                        },
                        color: Colors.white,
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class HomePageContent extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        children: [
          CarouselSlider(
            options: CarouselOptions(
              height: 200.0,
              enlargeCenterPage: true,
              autoPlay: true,
              aspectRatio: 16 / 9,
              autoPlayCurve: Curves.bounceOut,
              enableInfiniteScroll: true,
              autoPlayAnimationDuration: Duration(milliseconds: 200),
              viewportFraction: 1,
            ),
            items: [
              'assets/adavnceimage.jpeg',
              'assets/chatgpt.jpeg',
              'assets/gglimage.jpeg',
            ].map((item) {
              return Builder(
                builder: (BuildContext context) {
                  return Container(
                    width: MediaQuery.of(context).size.width,
                    margin: EdgeInsets.symmetric(horizontal: 5.0),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8.0),
                      image: DecorationImage(
                        image: AssetImage(item),
                        fit: BoxFit.cover,
                      ),
                    ),
                  );
                },
              );
            }).toList(),
          ),
          Divider(
            height: 70,
          ),
          Padding(
            padding: const EdgeInsets.only(top: 70.0),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  SizedBox(width: 20),
                  CategoryItem(
                    imagePath: 'assets/offlinecategory.png',
                    description: 'Offline Courses',
                    route: '/offlineCourses',
                  ),
                  SizedBox(width: 25),
                  CategoryItem(
                    imagePath: 'assets/onlinecategory.jpg',
                    description: 'Online Courses',
                    route: '/onlineCourses',
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class CategoryItem extends StatelessWidget {
  final String imagePath;
  final String description;
  final String route;

  const CategoryItem({
    required this.imagePath,
    required this.description,
    required this.route,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        Navigator.pushNamed(context, route);
      },
      child: Column(
        children: [
          Image.asset(
            imagePath,
            width: 150,
            height: 150,
          ),
          SizedBox(height: 10),
          Text(description),
        ],
      ),
    );
  }
}
