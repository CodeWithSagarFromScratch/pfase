import 'package:flutter/material.dart';
import 'Login_Srceen.dart';

class DrawerMenuItom extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blueAccent,
        title: Text('Home'),
        actions: [
          IconButton(
            icon: Icon(Icons.exit_to_app),
            onPressed: () {
              // Perform sign out action here
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => LoginScreen()),
              );
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.only(top: 50),
        child: Column(
          // mainAxisAlignment: MainAxisAlignment.center,
          // crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Row(
              // mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.exit_to_app),
                SizedBox(width: 5),
                TextButton(
                  onPressed: () {
                    // Sign out action
                    Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(builder: (context) => LoginScreen()),
                    );
                  },
                  child: Text('Sign out'),
                ),
              ],
            ),
            SizedBox(height: 20),
            Row(
              //  mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.star),
                SizedBox(width: 5),
                TextButton(
                  onPressed: () {
                    // Rate app action
                    // Implement your rate app functionality here
                  },
                  child: Text('Rate app'),
                ),
              ],
            ),
            SizedBox(height: 20),
            Row(
              //  mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.privacy_tip),
                SizedBox(width: 5),
                TextButton(
                  onPressed: () {
                    // Navigate to privacy policy page
                    // Implement navigation here
                  },
                  child: Text('Privacy Policy'),
                ),
              ],
            ),
            SizedBox(height: 20),
            Row(
              //  mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.account_balance_rounded),
                SizedBox(width: 5),
                TextButton(
                  onPressed: () {
                    // Navigate to privacy policy page
                    // Implement navigation here
                  },
                  child: Text('Refer And Learn'),
                ),
              ],
            ),
            SizedBox(height: 20),
            Row(
              //  mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.share),
                SizedBox(width: 5),
                TextButton(
                  onPressed: () {
                    // Navigate to privacy policy page
                    // Implement navigation here
                  },
                  child: Text('Share Simply Learn APP'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
