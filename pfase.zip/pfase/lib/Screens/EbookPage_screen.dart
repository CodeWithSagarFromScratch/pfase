import 'package:flutter/material.dart';
// import 'package:flutter_pdfview/flutter_pdfview.dart';

class EbookViewerPage extends StatelessWidget {
  final String ebookPath;

  EbookViewerPage({required this.ebookPath});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Ebook Viewer'),
      ),
      // body: PDFView(
      //   filePath: ebookPath,
      // ),
    );
  }
}
