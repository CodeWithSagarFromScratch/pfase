import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'TestPage_screen.dart'; // Import the next page file

class ListeningTest extends StatefulWidget {
  @override
  _ListeningTestState createState() => _ListeningTestState();
}

class _ListeningTestState extends State<ListeningTest> {
  late VideoPlayerController _controller;
  late Future<void> _initializeVideoPlayerFuture;
  late bool _isVideoPlaying = false;
  double _currentSliderValue = 0.0;
  String selectedAnswer = '';
  late SharedPreferences _prefs;
  final String _prefsKey = 'video_position';

  @override
  void initState() {
    super.initState();
    _controller = VideoPlayerController.network(
      'https://drive.google.com/uc?export=download&id=157IH5qTNyDhAfQ8ylAdOHVJ4NVFbPpCP', // Replace with the modified direct download link
    );
    _initializeVideoPlayerFuture = _initializePlayer();
  }

  Future<void> _initializePlayer() async {
    await _controller.initialize();
    await _loadPrefs();
    setState(() {
      _currentSliderValue = _controller.value.position.inSeconds.toDouble();
    });
    _controller.addListener(() {
      setState(() {
        _currentSliderValue = _controller.value.position.inSeconds.toDouble();
      });
    });
  }

  Future<void> _loadPrefs() async {
    _prefs = await SharedPreferences.getInstance();
    final int? savedPosition = _prefs.getInt(_prefsKey);
    if (savedPosition != null) {
      await _controller.seekTo(Duration(seconds: savedPosition));
      setState(() {
        _isVideoPlaying = false;
      });
    }
  }

  void _toggleVideo() {
    setState(() {
      _isVideoPlaying = !_isVideoPlaying;
      if (_isVideoPlaying) {
        _controller.play();
      } else {
        _controller.pause();
      }
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  void deactivate() {
    _savePrefs();
    super.deactivate();
  }

  void _savePrefs() async {
    final Duration position = _controller.value.position;
    await _prefs.setInt(_prefsKey, position.inSeconds);
  }

  void _nextPage() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => TestPageScreen()), // Navigate to the next page
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.indigo,
        title: Text('Listening Test',style: TextStyle(color: Colors.white)),
        iconTheme: IconThemeData(color: Colors.white),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
            _controller.pause();
          },
        ),
      ),
      body: Center(
        child: Container(
          padding: EdgeInsets.all(10.0),
          child: Column(
            children: [
              GestureDetector(
                onTap: _toggleVideo,
                child: Container(
                  width: 350,
                  height: 200,
                  color: Colors.black,
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      FutureBuilder(
                        future: _initializeVideoPlayerFuture,
                        builder: (context, snapshot) {
                          if (snapshot.connectionState == ConnectionState.done) {
                            return AspectRatio(
                              aspectRatio: _controller.value.aspectRatio,
                              child: VideoPlayer(_controller),
                            );
                          } else {
                            return Center(child: CircularProgressIndicator());
                          }
                        },
                      ),
                      Visibility(
                        visible: !_isVideoPlaying,
                        child: Icon(
                          Icons.play_arrow,
                          color: Colors.white,
                          size: 50,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 20),
              Slider(
                value: _currentSliderValue,
                min: 0.0,
                max: _controller.value.duration.inSeconds.toDouble(),
                onChanged: (double value) {
                  setState(() {
                    _currentSliderValue = value;
                  });
                },
                onChangeEnd: (double value) {
                  _controller.seekTo(Duration(seconds: value.toInt()));
                },
              ),
              Divider(
                height: 20,
                thickness: 3,
              ),
              SizedBox(height: 20),
              Text(
                'Q1] What is java?',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 10),
              SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    RadioListTile<String>(
                      title: Text('Java is Language'),
                      value: 'Option 1',
                      groupValue: selectedAnswer,
                      onChanged: (value) {
                        setState(() {
                          selectedAnswer = value!;
                        });
                      },
                    ),
                    RadioListTile<String>(
                      title: Text('Java is framework'),
                      value: 'Option 2',
                      groupValue: selectedAnswer,
                      onChanged: (value) {
                        setState(() {
                          selectedAnswer = value!;
                        });
                      },
                    ),
                    RadioListTile<String>(
                      title: Text('Java is SDK'),
                      value: 'Option 3',
                      groupValue: selectedAnswer,
                      onChanged: (value) {
                        setState(() {
                          selectedAnswer = value!;
                        });
                      },
                    ),
                    RadioListTile<String>(
                      title: Text('Java is tree'),
                      value: 'Option 4',
                      groupValue: selectedAnswer,
                      onChanged: (value) {
                        setState(() {
                          selectedAnswer = value!;
                        });
                      },
                    ),
                  ],
                ),
              ),
              SizedBox(height: 20),
              ElevatedButton.icon(
                onPressed: _nextPage,
                label: Text(
                  'Next',
                  style: TextStyle(color: Colors.white), // Set text color to white
                ),
                icon: Icon(Icons.arrow_forward, color: Colors.white), // Arrow icon color is white
                style: ButtonStyle(
                  backgroundColor: MaterialStateProperty.all<Color>(Colors.deepOrange), // Set button background color to indigo
                ),
              ),



            ],
          ),
        ),
      ),
    );
  }
}
