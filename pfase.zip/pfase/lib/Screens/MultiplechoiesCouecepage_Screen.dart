import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'OfflineCourses_screen.dart';

class MultiplechoiCource extends StatelessWidget {
  const MultiplechoiCource({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('My Course'),
      ),
      body: GestureDetector(
        onTap: () {
          // Navigate to the course details page
          Navigator.push(
            context,
            MaterialPageRoute(
              //   builder: (context) => VideoScreen()),
                builder: (context) => SliderPage()),
          );
        },
        child: Container(
        width: 360,
        height: 160,
        padding: EdgeInsets.all(10),
        margin: EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(10),
          boxShadow: [
            BoxShadow(
              color: Colors.grey,
              blurRadius: 5,
              spreadRadius: 2,
              offset: Offset(0, 2),
            ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.only(bottom: 50),
          child: Row(
            children: [
              Expanded(
                child: Row(
                  children: [
                    Column(
                      crossAxisAlignment:
                      CrossAxisAlignment.start,
                      children: [
                        Text(
                          'power BI for Beginners',
                          style: TextStyle(
                            color: Colors.black,
                            fontWeight:
                            FontWeight.bold,
                            fontSize: 18,
                          ),
                        ),
                        SizedBox(
                          height: 5,
                        ),
                        Row(
                          children: [
                            Icon(
                              Icons.star,
                              color: Colors.yellow,
                            ),
                            SizedBox(width: 5),
                            // Adjust spacing as needed
                            Text(
                              '4.6',
                              style: TextStyle(
                                color: Colors.black,
                                fontWeight:
                                FontWeight.bold,
                              ),
                            ),
                            SizedBox(width: 5),
                            // Adjust spacing as needed
                            Text(
                              '155k learners',
                              style: TextStyle(
                                color: Colors.black,
                              ),
                            ),
                          ],
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Row(
                          children: [
                            Icon(
                              Icons.emoji_events,
                              color: Colors.indigo,
                            ),
                            SizedBox(width: 5),
                            // Adjust spacing as needed
                            Text(
                              'Enroll and win rewards',
                              style: TextStyle(
                                color: Colors.black,
                              ),
                            ),
                          ],
                        )
                      ],
                    ),
                  ],
                ),
              ),
              SizedBox(
                width: 10,
              ),
              ClipRRect(
                borderRadius:
                BorderRadius.circular(15),
                child: Image.asset(
                  'assets/offlinecategory.png',
                  width: 70,
                  height: 70,
                  fit: BoxFit.cover,
                ),
              ),
            ],
          ),
        ),
            ),
      ),

    );
  }
}
