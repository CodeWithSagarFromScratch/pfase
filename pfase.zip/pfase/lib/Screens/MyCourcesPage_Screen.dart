
import 'package:flutter/material.dart';

import 'MultiplechoiesCouecepage_Screen.dart';
class CourseCard extends StatelessWidget {
  final double percentageComplete;

  CourseCard({required this.percentageComplete});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              width: 360,
              height: 200,
              padding: EdgeInsets.all(10),
              margin: EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey,
                    blurRadius: 5,
                    spreadRadius: 2,
                    offset: Offset(0, 2),
                  ),
                ],
              ),
              child: Padding(
                padding: const EdgeInsets.only(bottom: 50),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Website UI/UX Designing Using\nChatGpt: Become a UI UX designer',
                            style: TextStyle(
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                              fontSize: 18,
                            ),
                          ),
                          SizedBox(
                            height: 5,
                          ),
                          Row(
                            children: [
                              Icon(
                                Icons.punch_clock_rounded,
                              ),
                              SizedBox(width: 5),
                              // Adjust spacing as needed
                              Text(
                                '86 days left',
                                style: TextStyle(
                                  color: Colors.black,
                                ),
                              ),
                            ],
                          ),
                          Divider(), // Divider added here
                          SizedBox(
                            height: 5,
                          ),
                          Row(
                            children: [
                              GestureDetector(
                                onTap: () {
                                  // Navigate to the next screen
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(builder: (context) => MultiplechoiCource()),
                                  );
                                },
                                child: Text(
                                  'Start Learning', // Text added here
                                  style: TextStyle(
                                    color: Colors.indigoAccent,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    // Circular progress indicator
                    Container(
                      width: 70,
                      height: 70,
                      child: Stack(
                        children: [
                          Center(
                            child: SizedBox(
                              width: 50,
                              height: 50,
                              child: CircularProgressIndicator(
                                value: percentageComplete / 100, // Set the progress value
                                strokeWidth: 5, // Set the stroke width
                                backgroundColor: Colors.grey[300], // Set the background color
                                valueColor: AlwaysStoppedAnimation<Color>(
                                    Colors.blue), // Set the foreground color
                              ),
                            ),
                          ),
                          Center(
                            child: Text(
                              '${percentageComplete.toInt()}%', // Show the percentage
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            // Add another container here
            // Container(
            //   width: 360,
            //   height: 167,
            //   padding: EdgeInsets.all(10),
            //   margin: EdgeInsets.all(10),
            //   decoration: BoxDecoration(
            //     //  color: Colors.lightBlueAccent,
            //     color: Colors.lightBlue[100],
            //     borderRadius: BorderRadius.circular(10),
            //     boxShadow: [
            //       BoxShadow(
            //         color: Colors.grey,
            //         blurRadius: 5,
            //         spreadRadius: 2,
            //         offset: Offset(0, 2),
            //       ),
            //     ],
            //   ),
            //   child: Padding(
            //     padding: const EdgeInsets.only(bottom: 50),
            //     child: Row(
            //       children: [
            //         Expanded(
            //           child: Column(
            //             crossAxisAlignment: CrossAxisAlignment.start,
            //             children: [
            //               Text(
            //                 'Invite Your friends',
            //                 style: TextStyle(
            //                   color: Colors.black,
            //                   fontWeight: FontWeight.bold,
            //                   fontSize: 18,
            //                 ),
            //               ),
            //               SizedBox(
            //                 height: 5,
            //               ),
            //               Row(
            //                 children: [
            //                   // Icon(
            //                   //   Icons.punch_clock_rounded,
            //                   // ),
            //                   SizedBox(width: 5),
            //                   // Adjust spacing as needed
            //                   Text(
            //                     'Enroll for as many SkillUp cources\nas you like for Free',
            //                     style: TextStyle(
            //                       color: Colors.black,
            //                     ),
            //                   ),
            //                 ],
            //               ),
            //               //    Divider(), // Divider added here
            //               SizedBox(
            //                 height: 5,
            //               ),
            //               Row(
            //                 children: [
            //                   Row(
            //                     children: [
            //                       Text(
            //                         'Invite Now', // Text added here
            //                         style: TextStyle(
            //                           color: Colors.indigoAccent,
            //                           fontWeight: FontWeight.bold,
            //                         ),
            //                       ),
            //                       Icon(
            //                         Icons.arrow_forward, // Use the arrow_forward icon
            //                         color: Colors.indigoAccent,
            //                       ),
            //                     ],
            //                   ),
            //
            //                 ],
            //               ),
            //             ],
            //           ),
            //         ),
            //         SizedBox(
            //           width: 10,
            //         ),
            //         // Circular progress indicator
            //         Container(
            //           width: 70,
            //           height: 70,
            //           child: Stack(
            //             children: [
            //               Center(
            //                 child: SizedBox(
            //                   width: 50,
            //                   height: 50,
            //                   child: Image.asset(
            //                     'assets/supriseimge2.png', // Replace 'assets/surprise_image.png' with your image path
            //                     width: 50, // Set the width to match the CircularProgressIndicator
            //                     height: 50, // Set the height to match the CircularProgressIndicator
            //                     fit: BoxFit.cover, // Adjust the fit as needed
            //                   ),
            //                 ),
            //               ),
            //               Center(
            //                 child: Text(
            //                   '${percentageComplete.toInt()}%', // Show the percentage
            //                   style: TextStyle(
            //                     fontSize: 12,
            //                     fontWeight: FontWeight.bold,
            //                   ),
            //                 ),
            //               ),
            //             ],
            //           ),
            //         ),
            //
            //       ],
            //     ),
            //   ),
            // ),
            // Container(
            //   width: 360,
            //   height: 400,
            //   padding: EdgeInsets.all(10),
            //   margin: EdgeInsets.all(10),
            //   decoration: BoxDecoration(
            //     //  color: Colors.lightBlueAccent,
            //     color: Colors.white,
            //     borderRadius: BorderRadius.circular(10),
            //     boxShadow: [
            //       BoxShadow(
            //         color: Colors.grey,
            //         blurRadius: 5,
            //         spreadRadius: 2,
            //         offset: Offset(0, 2),
            //       ),
            //     ],
            //   ),
            //   child: Padding(
            //     padding: const EdgeInsets.only(bottom: 50),
            //     child: Row(
            //       children: [
            //         Expanded(
            //           child: Column(
            //             crossAxisAlignment: CrossAxisAlignment.start,
            //             children: [
            //               Text(
            //                 'Learning Status',
            //                 style: TextStyle(
            //                   color: Colors.black,
            //                   fontWeight: FontWeight.bold,
            //                   fontSize: 18,
            //                 ),
            //               ),
            //               SizedBox(
            //                 height: 10,
            //               ),
            //               Row(
            //                 children: [
            //                   Icon(
            //                     Icons.book,
            //                     size: 30, // Adjust the size as needed
            //                     color: Colors.blue, // Adjust the color as needed
            //                   ),
            //                   // SizedBox(width:0), // Add some space between the icons
            //
            //                   SizedBox(width: 5),
            //                   // Adjust spacing as needed
            //                   Text(
            //                     'Hi sagar! Get started on your learning journy.',
            //                     style: TextStyle(
            //                       color: Colors.black,
            //                     ),
            //                   ),
            //                 ],
            //               ),
            //               //    Divider(), // Divider added here
            //               SizedBox(
            //                 height: 20,
            //               ),
            //               Row(
            //                 children: [
            //                   Expanded(
            //                     child: Container(
            //                       height: 100,
            //                       decoration: BoxDecoration(
            //                         border: Border.all(color: Colors.yellow, width: 2), // Add a yellow border
            //                         borderRadius: BorderRadius.circular(20), // Set border radius for circular border
            //                       ),
            //                       child: Container(
            //                         color: Colors.white,
            //                         child: Padding(
            //                           padding: const EdgeInsets.only(bottom: 40),
            //                           child: Column(
            //                             crossAxisAlignment: CrossAxisAlignment.start,
            //                             children: [
            //                               Row(
            //                                 children: [
            //                                   Padding(
            //                                     padding: const EdgeInsets.symmetric(horizontal: 10),
            //                                     child: Icon(
            //                                       Icons.watch,
            //                                       color: Colors.yellow,
            //                                     ),
            //                                   ),
            //                                   Text(
            //                                     '0',
            //                                     style: TextStyle(
            //                                         color: Colors.black,
            //                                         fontWeight: FontWeight.bold
            //                                     ),
            //                                   ),
            //                                   Spacer(), // Add spacer to push the share icon to the end
            //                                   Padding(
            //                                     padding: const EdgeInsets.symmetric(horizontal: 10),
            //                                     child: Icon(
            //                                       Icons.share,
            //                                       color: Colors.black,
            //                                     ),
            //                                   ),
            //                                 ],
            //                               ),
            //                               SizedBox(height: 10), // Add some space between the rows
            //                               Row(
            //                                 children: [
            //                                   Padding(
            //                                     padding: const EdgeInsets.symmetric(horizontal: 10),
            //                                     child: Text(
            //                                       'Learning Mins',
            //                                       style: TextStyle(
            //                                         color: Colors.black,
            //                                       ),
            //                                     ),
            //                                   ),
            //                                 ],
            //                               ),
            //                             ],
            //                           ),
            //                         ),
            //                       ),
            //                     ),
            //                   ),
            //                   SizedBox(width: 10), // Add spacing between the containers
            //                   Expanded(
            //                     child: Container(
            //                       height: 100,
            //                       decoration: BoxDecoration(
            //                         border: Border.all(color: Colors.yellow, width: 2), // Add a yellow border
            //                         borderRadius: BorderRadius.circular(20), // Set border radius for circular border
            //                       ),
            //                       child: Container(
            //                         color: Colors.white,
            //                         child: Padding(
            //                           padding: const EdgeInsets.only(bottom: 40),
            //                           child: Column(
            //                             crossAxisAlignment: CrossAxisAlignment.start,
            //                             children: [
            //                               Row(
            //                                 children: [
            //                                   Padding(
            //                                     padding: const EdgeInsets.symmetric(horizontal: 10),
            //                                     child: Icon(
            //                                       Icons.watch,
            //                                       color: Colors.orange,
            //                                     ),
            //                                   ),
            //                                   Text(
            //                                     '0%',
            //                                     style: TextStyle(
            //                                         color: Colors.black,
            //                                         fontWeight: FontWeight.bold
            //                                     ),
            //                                   ),
            //                                   Spacer(), // Add spacer to push the share icon to the end
            //                                   Padding(
            //                                     padding: const EdgeInsets.symmetric(horizontal: 10),
            //                                     // child: Icon(
            //                                     //   Icons.share,
            //                                     //   color: Colors.black,
            //                                     // ),
            //                                   ),
            //                                 ],
            //                               ),
            //                               SizedBox(height: 10), // Add some space between the rows
            //                               Row(
            //                                 children: [
            //                                   Padding(
            //                                     padding: const EdgeInsets.symmetric(horizontal: 10),
            //                                     child: Text(
            //                                       'Quiz Accuracy',
            //                                       style: TextStyle(
            //                                         color: Colors.black,
            //                                       ),
            //                                     ),
            //                                   ),
            //                                 ],
            //                               ),
            //                             ],
            //                           ),
            //                         ),
            //                       ),
            //                     ),
            //                   ),
            //                 ],
            //               ),
            //
            //
            //
            //
            //               SizedBox(height: 30,),
            //               // Container(
            //               //   height: 100,
            //               //   width: 150,
            //               //   decoration: BoxDecoration(
            //               //     border: Border.all(color: Colors.yellow, width: 2), // Add a yellow border
            //               //     borderRadius: BorderRadius.circular(20), // Set border radius for circular border
            //               //   ),
            //               //   child: Container(
            //               //     color: Colors.white,
            //               //     child: Padding(
            //               //       padding: const EdgeInsets.only(top: 75),
            //               //       child: Text('Topic Completed'),
            //               //     ),
            //               //   ),
            //               // ),
            //               Row(
            //                 children: [
            //                   Expanded(
            //                     child: Container(
            //                       height: 100,
            //                       decoration: BoxDecoration(
            //                         border: Border.all(color: Colors.yellow, width: 2), // Add a yellow border
            //                         borderRadius: BorderRadius.circular(20), // Set border radius for circular border
            //                       ),
            //                       child: Container(
            //                         color: Colors.white,
            //                         child: Padding(
            //                           padding: const EdgeInsets.only(bottom: 40),
            //                           child: Column(
            //                             crossAxisAlignment: CrossAxisAlignment.start,
            //                             children: [
            //                               Row(
            //                                 children: [
            //                                   Padding(
            //                                     padding: const EdgeInsets.symmetric(horizontal: 10),
            //                                     child: Icon(
            //                                       Icons.watch,
            //                                       color: Colors.orange,
            //                                     ),
            //                                   ),
            //                                   Text(
            //                                     '0',
            //                                     style: TextStyle(
            //                                         color: Colors.black,
            //                                         fontWeight: FontWeight.bold
            //                                     ),
            //                                   ),
            //                                   Spacer(), // Add spacer to push the share icon to the end
            //                                   Padding(
            //                                     padding: const EdgeInsets.symmetric(horizontal: 10),
            //                                     // child: Icon(
            //                                     //   Icons.share,
            //                                     //   color: Colors.black,
            //                                     // ),
            //                                   ),
            //                                 ],
            //                               ),
            //                               SizedBox(height: 10), // Add some space between the rows
            //                               Row(
            //                                 children: [
            //                                   Padding(
            //                                     padding: const EdgeInsets.symmetric(horizontal: 10),
            //                                     child: Text(
            //                                       'Topic Completed',
            //                                       style: TextStyle(
            //                                         color: Colors.black,
            //                                       ),
            //                                     ),
            //                                   ),
            //                                 ],
            //                               ),
            //                             ],
            //                           ),
            //                         ),
            //                       ),
            //                     ),
            //                   ),
            //                   SizedBox(width: 10), // Add spacing between the containers
            //                   Expanded(
            //                     child: Container(
            //                       height: 100,
            //                       decoration: BoxDecoration(
            //                         border: Border.all(color: Colors.yellow, width: 2), // Add a yellow border
            //                         borderRadius: BorderRadius.circular(20), // Set border radius for circular border
            //                       ),
            //                       child: Container(
            //                         color: Colors.white,
            //                         child: Padding(
            //                           padding: const EdgeInsets.only(bottom: 40),
            //                           child: Column(
            //                             crossAxisAlignment: CrossAxisAlignment.start,
            //                             children: [
            //                               Row(
            //                                 children: [
            //                                   Padding(
            //                                     padding: const EdgeInsets.symmetric(horizontal: 10),
            //                                     child: Icon(
            //                                       Icons.watch,
            //                                       color: Colors.orange,
            //                                     ),
            //                                   ),
            //                                   Text(
            //                                     '0',
            //                                     style: TextStyle(
            //                                         color: Colors.black,
            //                                         fontWeight: FontWeight.bold
            //                                     ),
            //                                   ),
            //                                   Spacer(), // Add spacer to push the share icon to the end
            //                                   Padding(
            //                                     padding: const EdgeInsets.symmetric(horizontal: 10),
            //                                     // child: Icon(
            //                                     //   Icons.share,
            //                                     //   color: Colors.black,
            //                                     // ),
            //                                   ),
            //                                 ],
            //                               ),
            //                               SizedBox(height: 10), // Add some space between the rows
            //                               Row(
            //                                 children: [
            //                                   Padding(
            //                                     padding: const EdgeInsets.symmetric(horizontal: 10),
            //                                     child: Text(
            //                                       ' Certificates',
            //                                       style: TextStyle(
            //                                         color: Colors.black,
            //                                       ),
            //                                     ),
            //                                   ),
            //                                 ],
            //                               ),
            //                             ],
            //                           ),
            //                         ),
            //                       ),
            //                     ),
            //                   ),
            //                 ],
            //               ),
            //
            //             ],
            //           ),
            //         ),
            //         SizedBox(
            //           width: 10,
            //         ),
            //         // Circular progress indicator
            //
            //
            //       ],
            //     ),
            //   ),
            // ),
            SizedBox(height: 5,),
            Container(
              width: 360,
              height: 200,
              padding: EdgeInsets.all(10),
              margin: EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey,
                    blurRadius: 5,
                    spreadRadius: 2,
                    offset: Offset(0, 2),
                  ),
                ],
              ),
              child: Padding(
                padding: const EdgeInsets.only(bottom: 50),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Powe BI For Beginners',
                            style: TextStyle(
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                              fontSize: 20,
                            ),
                          ),
                          SizedBox(
                            height: 5,
                          ),
                          Row(
                            children: [
                              Icon(
                                Icons.punch_clock_rounded,
                              ),
                              SizedBox(width: 5),
                              // Adjust spacing as needed
                              Text(
                                '86 days left',
                                style: TextStyle(
                                  color: Colors.black,
                                ),
                              ),
                            ],
                          ),
                          Divider(), // Divider added here
                          SizedBox(
                            height: 5,
                          ),
                          Row(
                            children: [
                              Text(
                                'Win your next rewards on completing10%', // Text added here
                                style: TextStyle(
                                  color: Colors.black,
                                fontSize: 15),
                              ),
                             // Icon(Icons.emoji_events)
                            ],
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    // Circular progress indicator
                    Container(
                      width: 70,
                      height: 70,
                      child: Stack(
                        children: [
                          Center(
                            child: SizedBox(
                              width: 50,
                              height: 50,
                              child: CircularProgressIndicator(
                                value: percentageComplete / 100, // Set the progress value
                                strokeWidth: 5, // Set the stroke width
                                backgroundColor: Colors.grey[300], // Set the background color
                                valueColor: AlwaysStoppedAnimation<Color>(
                                    Colors.blue), // Set the foreground color
                              ),
                            ),
                          ),
                          Center(
                            child: Text(
                              '${percentageComplete.toInt()}%', // Show the percentage
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}