import 'package:flutter/material.dart';
import 'EbookPage_screen.dart';
import 'QuizePage_Screen.dart';
import 'TestPage_screen.dart';
import 'chpater1_video_screen.dart';

class SliderPage extends StatefulWidget {
  @override
  _SliderPageState createState() => _SliderPageState();
}

class _SliderPageState extends State<SliderPage> {
  final List<String> options = ['Video', 'Quiz', 'Test', 'Ebook','MockTest','Practise Paper','Assessment'];
  int selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    double appBarHeight = kToolbarHeight +
        60; // Default AppBar height + additional height for options and text
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(appBarHeight),
        child: AppBar(
          title: Text('Website UI/UX Desigining using',style: TextStyle(color: Colors.white),),
          iconTheme: IconThemeData(color: Colors.white),

          backgroundColor: Colors.indigo,
          flexibleSpace: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(height: kToolbarHeight + 10),
              // Adjust the height as needed

              SizedBox(height: 10),
              // Adjust the height as needed
              SingleChildScrollView( // Wrap the Row in SingleChildScrollView
                scrollDirection: Axis.horizontal, // Set scroll direction to horizontal
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: List.generate(
                    options.length,
                        (index) => GestureDetector(
                      onTap: () {
                        setState(() {
                          selectedIndex = index;
                        });
                      },
                      child: Container(
                        alignment: Alignment.center,
                        padding: EdgeInsets.symmetric(horizontal: 10),
                        color: index == selectedIndex
                            ? Colors.white
                            : Colors.transparent,
                        child: Text(
                          options[index],
                          style: TextStyle(
                            color: index == selectedIndex
                                ? Colors.blue
                                : Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 18,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      body: getContent(selectedIndex),
    );
  }

  Widget getContent(int index) {
    switch (index) {
      case 0:
        return VideoScreen();
      case 1:
        return QuizPage();
      //  return Assignment_page();
      case 2:
      //  return QuizPage();
        return TestPageScreen();
      case 3:
       // return TestPageScreen(); // Provide ebook path if needed
        return EbookViewerPage(ebookPath: '');// Provide ebook path if needed
      case 4:
        return TestPageScreen();
      case 5:
        return TestPageScreen();
      case 6:
        return TestPageScreen();
      case 7:
        return TestPageScreen();
      default:
        return SizedBox.shrink();
    }
  }
}



class OptionSlider extends StatelessWidget {
  final List<String> options;
  final int selectedIndex;
  final Function(int) onOptionSelected;

  const OptionSlider({
    required this.options,
    required this.selectedIndex,
    required this.onOptionSelected,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 50,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: options.length,
        itemBuilder: (context, index) {
          return GestureDetector(
            onTap: () {
              onOptionSelected(index);
            },
            child: Container(
              alignment: Alignment.center,
              margin: EdgeInsets.symmetric(horizontal: 10),
              padding: EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: index == selectedIndex ? Colors.blue : Colors.grey,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Text(
                options[index],
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
