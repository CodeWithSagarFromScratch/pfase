import 'package:flutter/material.dart';

class QuizPage extends StatefulWidget {
  @override
  _QuizPageState createState() => _QuizPageState();
}

class _QuizPageState extends State<QuizPage> {
  // List of questions and answers
  final List<Map<String, dynamic>> questions = [
    {
      'question': 'What is the capital of France?',
      'options': ['London', 'Paris', 'Berlin', 'Rome'],
      'correctAnswerIndex': 1,
    },
    {
      'question': 'What is 2 + 2?',
      'options': ['3', '4', '5', '6'],
      'correctAnswerIndex': 1,
    },
    {
      'question': 'Which planet is known as the Red Planet?',
      'options': ['Earth', 'Jupiter', 'Mars', 'Venus'],
      'correctAnswerIndex': 2,
    },
  ];

  // Variables to track current question index and user's score
  int currentQuestionIndex = 0;
  int score = 0;

  // Function to handle user's answer selection
  void selectAnswer(int selectedIndex) {
    if (selectedIndex == questions[currentQuestionIndex]['correctAnswerIndex']) {
      // Increment score if the answer is correct
      setState(() {
        score++;
      });
    }
    // Move to the next question
    setState(() {
      if (currentQuestionIndex < questions.length - 1) {
        currentQuestionIndex++;
      } else {
        // Quiz is complete, show results
        _showResults();
      }
    });
  }

  // Function to show quiz results
  void _showResults() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('Quiz Complete'),
        content: Text('You scored $score out of ${questions.length}'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              // Optionally reset quiz for retake
              // setState(() {
              //   currentQuestionIndex = 0;
              //   score = 0;
              // });
            },
            child: Text('OK'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // appBar: AppBar(
      //   title: Text('Quiz Page'),
      // ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              'Question ${currentQuestionIndex + 1}:',
              style: TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8.0),
            Text(
              questions[currentQuestionIndex]['question'],
              style: TextStyle(fontSize: 18.0),
            ),
            SizedBox(height: 16.0),
            ...List.generate(
              questions[currentQuestionIndex]['options'].length,
                  (index) => ElevatedButton(
                onPressed: () {
                  selectAnswer(index);
                },
                child: Text(questions[currentQuestionIndex]['options'][index]),
              ),
            ),
          ],
        ),
      ),
    );
  }
}


