import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_sound/flutter_sound.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:path/path.dart' as path;
import 'package:assets_audio_player/assets_audio_player.dart';
import 'package:intl/intl.dart' show DateFormat;

class redingtestnewpage extends StatefulWidget {
  redingtestnewpage({required this.title});

  final String title;

  @override
  _redingtestnewpageState createState() => _redingtestnewpageState();
}

class _redingtestnewpageState extends State<redingtestnewpage> {
  late FlutterSoundRecorder _myRecorder;
  final audioPlayer = AssetsAudioPlayer();
  late String filePath;
  bool _play = false;
  String _recorderTxt = '00:00:00';

  @override
  void initState() {
    super.initState();
    startIt();
  }

  void startIt() async {
    filePath = '/sdcard/Download/temp.wav';
    _myRecorder = FlutterSoundRecorder();

    await _myRecorder.openAudioSession(
        focus: AudioFocus.requestFocusAndStopOthers,
        category: SessionCategory.playAndRecord,
        mode: SessionMode.modeDefault,
        device: AudioDevice.speaker);
    await _myRecorder.setSubscriptionDuration(Duration(milliseconds: 10));
    await initializeDateFormatting();

    await Permission.microphone.request();
    await Permission.storage.request();
    await Permission.manageExternalStorage.request();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        extendBodyBehindAppBar: true,
        backgroundColor: Colors.white,
        appBar: AppBar(

          title: Text('Reading Test',style: TextStyle(color: Colors.white)),
          iconTheme: IconThemeData(color: Colors.white),
          backgroundColor: Colors.indigo,
          elevation: 0.0,
        ),
        body: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Expanded(
              child: SingleChildScrollView(
                child: Container(
                  width: MediaQuery.of(context).size.width * 0.8,
                  padding: EdgeInsets.symmetric(vertical: 60.0),
                  child: Text(
                    '     Write an essay on the following topic In todays digital age, programming has emerged as a transformative force, '
                    'shaping the way we interact with technology, solve problems, and navigate the world around us. From mobile applications to artificial intelligence, programming'
                    ' permeates every aspect of modern life, revolutionizing industries, economies,'
                    ' and societies. In this essay, we explore the profound impact of programming, its significance in contemporary society, and its role in shaping the future.',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
            ),
            Divider(),
            SizedBox(height: 20),
            Expanded(
              child: Center(
                child: Container(
                  height: 200.0,
                  width: MediaQuery.of(context).size.width,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Color.fromARGB(255, 2, 199, 226),
                        Color.fromARGB(255, 6, 75, 210)
                      ],
                    ),
                    borderRadius: BorderRadius.vertical(
                      bottom: Radius.elliptical(
                          MediaQuery.of(context).size.width, 100.0),
                    ),
                  ),
                  child: Center(
                    child: Text(
                      _recorderTxt,
                      style: TextStyle(fontSize: 40),
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                buildElevatedButton(
                  icon: Icons.mic,
                  iconColor: Colors.red,
                  f: record,
                ),
                SizedBox(width: 30),
                buildElevatedButton(
                  icon: Icons.stop,
                  iconColor: Colors.black,
                  f: stopRecord,
                ),
                SizedBox(width: 30),
                buildElevatedButton(
                  icon: Icons.play_arrow,
                  iconColor: Colors.black,
                  f: startPlaying,
                ),
                SizedBox(width: 30),
                buildElevatedButton(
                  icon: Icons.stop,
                  iconColor: Colors.black,
                  f: stopPlaying,
                ),
              ],
            ),
            SizedBox(height: 20),
            ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                elevation: 10.0,
              ),
              onPressed: () {
                setState(() {
                  _play = !_play;
                });
                if (_play)
                  startPlaying();
                else
                  stopPlaying();
              },
              icon: _play ? Icon(Icons.stop) : Icon(Icons.play_arrow),
              label: _play
                  ? Text(
                      "Stop Playing",
                      style: TextStyle(
                        fontSize: 25,
                      ),
                    )
                  : Text(
                      "Start Playing",
                      style: TextStyle(
                        fontSize: 25,
                      ),
                    ),
            ),
          ],
        ),
      ),
    );
  }

  ElevatedButton buildElevatedButton(
      {required IconData icon, required Color iconColor, Function? f}) {
    return ElevatedButton.icon(
      style: ElevatedButton.styleFrom(
        padding: EdgeInsets.all(5.0),
        backgroundColor: Colors.white,
        side: BorderSide(
          color: Colors.orange,
          width: 3.0,
        ),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15),
        ),
        elevation: 10.0,
      ),
      onPressed: f as void Function()?,
      icon: Icon(
        icon,
        color: iconColor,
        size: 35.0,
      ),
      label: Text(''),
    );
  }

  void record() async {
    Directory dir = Directory(path.dirname(filePath));
    if (!dir.existsSync()) {
      dir.createSync();
    }
    _myRecorder.openAudioSession();
    await _myRecorder.startRecorder(
      toFile: filePath,
      codec: Codec.pcm16WAV,
    );

    _myRecorder.onProgress?.listen((e) {
      var date = DateTime.fromMillisecondsSinceEpoch(e.duration.inMilliseconds,
          isUtc: true);
      var txt = DateFormat('mm:ss:SS', 'en_GB').format(date);

      setState(() {
        _recorderTxt = txt.substring(0, 8);
      });
    });
  }

  void stopRecord() async {
    _myRecorder.closeAudioSession();
    await _myRecorder.stopRecorder();
  }

  void startPlaying() async {
    audioPlayer.open(
      Audio.file(filePath),
      autoStart: true,
      showNotification: true,
    );
  }

  void stopPlaying() async {
    audioPlayer.stop();
  }
}
