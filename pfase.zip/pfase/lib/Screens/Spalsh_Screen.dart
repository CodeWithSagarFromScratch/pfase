import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'Login_Srceen.dart'; // For SystemChrome
// Import any other dependencies you might need


class SpalshScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // Set preferred orientation to portrait
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: LoginScreen(),
    );
  }
}

class SplashScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return
      Scaffold(
      backgroundColor: Colors.white, // Customize background color if needed
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            // Your logo image
            Image.asset(
              'assets/pcfsmLogo.jpeg', // Replace 'logo.png' with your actual logo path
              width: 200, // Adjust width as needed
              height: 200, // Adjust height as needed
            ),
            SizedBox(height: 24), // Add some spacing
            // You can add additional widgets here if needed
          ],
        ),
      ),
    );
  }
}
