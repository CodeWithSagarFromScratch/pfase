import 'package:flutter/material.dart';
import 'Cource_details_screen.dart';
import 'chpater1_video_screen.dart';
import 'package:carousel_slider/carousel_slider.dart';

class SubCategoryPage extends StatefulWidget {
  const SubCategoryPage({Key? key}) : super(key: key);

  @override
  _SubCategoryPageState createState() => _SubCategoryPageState();
}

class _SubCategoryPageState extends State<SubCategoryPage> {
  final List<String> sliderImages = [
    'assets/adavnceimage.jpeg',
    'assets/chatgpt.jpeg',
    'assets/gglimage.jpeg',
    // Add more slider images here if needed
  ];

  final List<String> images = [
    'assets/offlinecategory.png',
    'assets/onlinecategory.jpg',
    'assets/onlinecategory.jpg',
    'assets/onlinecategory.jpg',
    'assets/offlinecategory.png',
    // Add more images here if needed
  ];

  final List<String> texts = [
    'Course 1',
    'Course 2',
    'Course 3',
    'Course 4',
    'Course 5',
    // Add corresponding texts here if needed
  ];

  final Map<String, WidgetBuilder> routes = {
    '/chapter1': (context) => TabExample(),
    '/chapter2': (context) => TabExample(),
    '/chapter3': (context) => TabExample(),
    '/chapter4': (context) => TabExample(), // Placeholder for chapter 4
    '/chapter5': (context) => TabExample(), // Placeholder for chapter 5
    // Add corresponding routes here if needed
  };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Select SubCategory',
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: Colors.indigo,
      ),
      body: SafeArea(
        child: Column(
          children: [
            CarouselSlider(
              items: sliderImages.map((image) {
                return Builder(
                  builder: (BuildContext context) {
                    return Image.asset(
                      image,
                      fit: BoxFit.cover,
                      width: MediaQuery.of(context).size.width,
                    );
                  },
                );
              }).toList(),
              options: CarouselOptions(
                height: 200.0,
                // Adjust slider height as needed
                autoPlay: true,
                enlargeCenterPage: true,
                viewportFraction: 1.0,
                aspectRatio: 16 / 9,
              ),
            ),
            Divider(), // Divider below the slider
            Expanded(
              child: GridView.count(
                crossAxisCount: 2, // Display two images in each row
                children: List.generate(images.length, (index) {
                  final route = '/chapter${index + 1}';
                  return InkWell(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: routes[route]!,
                        ),
                      );
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Card(
                        elevation: 3,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: <Widget>[
                            Expanded(
                              child: AspectRatio(
                                aspectRatio: 1, // Set aspect ratio as needed
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(10),
                                  child: Image.asset(
                                    images[index],
                                    fit: BoxFit.cover,
                                    height: 150, // Adjust image height
                                    width: double
                                        .infinity, // Adjust image width to fill the expanded widget
                                  ),
                                ),
                              ),
                            ),
                            Padding(
                              padding: EdgeInsets.all(10.0),
                              child: Text(
                                texts[index],
                                style: TextStyle(
                                  fontSize: 20.0,
                                  fontWeight: FontWeight.bold,
                                ),
                                textAlign: TextAlign.center,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                }),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
