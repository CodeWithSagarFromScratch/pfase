import 'package:flutter/material.dart';
class TestPageScreen extends StatefulWidget {
  @override
  _TestPageScreenState createState() => _TestPageScreenState();
}

class _TestPageScreenState extends State<TestPageScreen> {
  // Example questions data
  List<Map<String, dynamic>> questions = [
    {
      'question': 'What is the capital of France?',
      'options': ['Paris', 'London', 'Berlin', 'Rome'],
      'correctAnswer': 'Paris',
    },
    {
      'question': 'What is the capital of France?',
      'options': ['Paris', 'London', 'Berlin', 'Rome'],
      'correctAnswer': 'Paris',
    },
    {
      'question': 'What is the capital .of France?',
      'options': ['Paris', 'London', 'Berlin', 'Rome'],
      'correctAnswer': 'Paris',
    },
    // Add more questions similarly
  ];

  Map<int, String> selectedOptions = {};

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
      //  title: Text('Student Test'),
      ),
      body: ListView.builder(
        itemCount: questions.length,
        itemBuilder: (context, index) {
          return Card(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text(
                    'Question ${index + 1}: ${questions[index]['question']}',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                ),
                ...List.generate(
                  questions[index]['options'].length,
                      (optionIndex) {
                    String option = questions[index]['options'][optionIndex];
                    return RadioListTile(
                      title: Text(option),
                      value: option,
                      groupValue: selectedOptions[index],
                      onChanged: (value) {
                        setState(() {
                          selectedOptions[index] = value.toString();
                        });
                      },
                    );
                  },
                ),
              ],
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // Handle submission
          submitTest();
        },
        backgroundColor: Colors.deepOrange, // Set the background color to deepOrange
        child: Text('Submit',style: TextStyle(color: Colors.white),),
      ),


    );
  }

  void submitTest() {
    int correctAnswers = 0;
    for (int i = 0; i < questions.length; i++) {
      if (selectedOptions.containsKey(i) && selectedOptions[i] == questions[i]['correctAnswer']) {
        correctAnswers++;
      }
    }
    // Provide feedback (e.g., show a dialog)
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Test Result'),
          content: Text('You scored $correctAnswers out of ${questions.length}'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: Text('OK'),
            ),
          ],
        );
      },
    );
  }
}