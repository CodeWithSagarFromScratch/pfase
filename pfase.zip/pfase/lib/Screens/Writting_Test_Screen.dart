import 'package:flutter/material.dart';

class WritingTestPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.indigo,
        title: Text('Writing Test',style: TextStyle(color: Colors.white)),
        iconTheme: IconThemeData(color: Colors.white),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Upper part with paragraph (half screen height)
          Expanded(
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // Paragraphs
                  // for (int i = 0; i < 10; i++) // Repeat the paragraphs 10 times
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Text(
                          '     Write an essay on the following topic In todays digital age, programming has emerged as a transformative force, '
                              'shaping the way we interact with technology, solve problems, and navigate the world around us. From mobile applications to artificial intelligence, programming'
                              ' permeates every aspect of modern life, revolutionizing industries, economies,'
                              ' and societies. In this essay, we explore the profound impact of programming, its significance in contemporary society, and its role in shaping the future.',
                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                        ),
                        SizedBox(height: 10),
                        Text(
                          'What are the advantages and disadvantages of online learning?',
                          style: TextStyle(fontSize: 16),
                        ),
                      ],
                    ),
                ],
              ),
            ),
          ),
          // Divider
          Divider(
            color: Colors.grey,
            thickness: 2,
            height: 20,
          ),
          // Writing field
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: TextField(
              maxLines: null, // Allow multiple lines for writing
              decoration: InputDecoration(
                hintText: 'Start writing here...',
                border: OutlineInputBorder(),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
