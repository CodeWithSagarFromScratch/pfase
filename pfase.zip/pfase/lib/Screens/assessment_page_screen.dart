import 'package:flutter/material.dart';
import 'package:pfase/Screens/speaking_test_Screen.dart';
import 'Cource_details_screen.dart';
import 'Listening_Test_Screen.dart';
import 'Readung_Test_Screen.dart';
import 'Writting_Test_Screen.dart';

class AssessmentPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      initialRoute: '/',
      onGenerateRoute: RouteGenerator.generateRoute,
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
    );
  }
}

class RouteGenerator {
  static Route<dynamic> generateRoute(RouteSettings settings) {
    // Get the route name
    final String? routeName = settings.name;

    // Check which route to navigate to based on the route name
    switch (routeName) {
      case '/':
        return MaterialPageRoute(builder: (_) => MenuPage());
      case '/speaking':
        return MaterialPageRoute(builder: (_) => SpeakingTestModule());
      case '/writing':
        return MaterialPageRoute(builder: (_) => WritingTestPage());
      case '/reading':
      //  return MaterialPageRoute(builder: (_) => ReadingTestPage());
        return MaterialPageRoute(builder: (_) => redingtestnewpage(title: '',));
      case '/listening':
        return MaterialPageRoute(builder: (_) => ListeningTest());
      default:
      // If route not found, return an error page
        return MaterialPageRoute(
          builder: (_) => Scaffold(
            appBar: AppBar(
              title: Text('Error'),
            ),
            body: Center(
              child: Text('Error: No route defined for $routeName'),
            ),
          ),
        );
    }
  }
}

class MenuPage extends StatefulWidget {
  @override
  _MenuPageState createState() => _MenuPageState();
}

class _MenuPageState extends State<MenuPage> {
  String selectedItem = ''; // Track the selected menu item

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.indigo,
        title: Text('Assessment',style: TextStyle(color: Colors.white)),
        iconTheme: IconThemeData(color: Colors.white),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            // Navigate back to the previous screen and replace it with TabExample()
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (context) => TabExample()),
            );
          },
        ),
      ),
      body: ListView(
        children: [
          buildMenuItem('Speaking Test', '/speaking'),
          buildMenuItem('Writing Test', '/writing'),
          buildMenuItem('Reading Test', '/reading'),
          buildMenuItem('Listening Test', '/listening'),
        ],
      ),
    );
  }

  Widget buildMenuItem(String title, String routeName) {
    return Card(
      elevation: 4,
      margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
      child: ListTile(
        title: Text(
          title,
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        onTap: () {
          // Navigate to the selected page
          Navigator.pushNamed(context, routeName).then((value) {
            // Update the selected item when returning from the page
            setState(() {
              selectedItem = routeName;
            });
          });
        },
        trailing: selectedItem == routeName ? Icon(Icons.check, color: Colors.green) : null,
      ),
    );
  }
}


class TestPage extends StatelessWidget {
  final String title;
  final String nextRoute;

  const TestPage({required this.title, required this.nextRoute});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Expanded(
            child: Center(
              child: Text('This is the $title page'),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pushNamed(context, nextRoute);
            },
            child: Text('Next'),
          ),
        ],
      ),
    );
  }
}
