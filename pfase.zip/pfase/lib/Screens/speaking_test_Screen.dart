import 'package:flutter/material.dart';
import 'package:camera/camera.dart';
import 'dart:async';

class SpeakingTestModule extends StatefulWidget {
  @override
  _SpeakingTestModuleState createState() => _SpeakingTestModuleState();
}

class _SpeakingTestModuleState extends State<SpeakingTestModule> {
  late CameraController _controller;
  late Future<void> _initializeControllerFuture;
  late Timer _timer;
  bool _isRecording = false;

  @override
  void initState() {
    super.initState();
    // Initialize the camera controller
    _initializeCamera();
  }

  // Function to initialize the camera
  Future<void> _initializeCamera() async {
    final cameras = await availableCameras();
    // Select the front camera
    CameraDescription frontCamera = cameras.firstWhere(
          (camera) => camera.lensDirection == CameraLensDirection.front,
      orElse: () => cameras[0], // If front camera is not available, use the default camera
    );
    _controller = CameraController(frontCamera, ResolutionPreset.medium);
    _initializeControllerFuture = _controller.initialize();

    setState(() {}); // Update the state to rebuild the widget tree
  }

  @override
  void dispose() {
    // Dispose of the camera controller and timer when not needed
    _controller.dispose();
    _timer.cancel(); // Cancel the timer to avoid memory leaks
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.indigo,
        title: Text(
          'Speaking Test Module',
          style: TextStyle(color: Colors.white),
        ),
        iconTheme: IconThemeData(color: Colors.white), // Set the color of the back arrow icon
      ),

      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Display the camera view
          Expanded(
            flex: 2,
            child: FutureBuilder<void>(
              future: _initializeControllerFuture,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.done) {
                  return CameraPreview(_controller);
                } else {
                  return Center(child: CircularProgressIndicator());
                }
              },
            ),
          ),
          // Display the paragraph for the speaking test
          Expanded(
            flex: 1,
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(
                'In todays digital age, programming has emerged as a transformative force, shaping the way we interact with technology, solve problems, and navigate the world around us. From mobile applications to '
                    'artificial intelligence, programming permeates every aspect of'
                    ' modern life, revolutionizing industries, economies, and societies. In this essay, we explore the profound impact of programming,',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 16),
              ),
            ),
          ),
          // Button to start recording
          ElevatedButton(
            onPressed: () async {
              try {
                if (!_isRecording) {
                  await _initializeControllerFuture;
                  await _controller.startVideoRecording();
                  _startTimer();
                  setState(() {
                    _isRecording = true;
                  });
                } else {
                  await _controller.stopVideoRecording();
                  _timer.cancel();
                  setState(() {
                    _isRecording = false;
                  });
                }
              } catch (e) {
                print("Error during video recording: $e");
              }
            },
            child: Text(_isRecording ? 'Stop Recording' : 'Start Recording'),
          ),

        ],
      ),
    );
  }

  // Function to start the timer
  void _startTimer() {
    const duration = Duration(seconds: 30); // Timer duration (30 seconds)
    _timer = Timer(duration, () {
      // Timer callback function (called after 30 seconds)
      _stopRecording();
    });
  }

  // Function to stop recording
  void _stopRecording() async {
    try {
      // Stop recording
      await _controller.stopVideoRecording();
      // Perform any additional logic after recording stops
    } catch (e) {
      print("Error: $e");
    }
  }
}

