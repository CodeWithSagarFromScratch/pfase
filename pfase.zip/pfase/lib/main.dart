import 'dart:async';
import 'package:flutter/material.dart';
import 'Screens/Login_Srceen.dart';
import 'Screens/SignUp_Screen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: SplashScreen(), // Set the splash screen as the home route
      routes: {
        '/login': (context) => LoginScreen(), // Set login screen route
        '/signup': (context) => SignUpScreen(), // Set signup screen route
      },
    );
  }
}

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    // Navigate to the login screen after a certain duration (e.g., 2 seconds)
    Timer(
      Duration(seconds: 2),
          () => Navigator.pushReplacementNamed(context, '/login'),
    );
  }

  @override
  Widget build(BuildContext context) {
    return
      Scaffold(
        backgroundColor: Colors.white, // Customize background color if needed
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              // Your logo image
              Image.asset(
                'assets/pfasenew_logo.PNG', // Replace 'logo.png' with your actual logo path
                width: 200, // Adjust width as needed
                height: 200, // Adjust height as needed
              ),
              SizedBox(height: 24), // Add some spacing
              // You can add additional widgets here if needed
            ],
          ),
        ),
      );
  }
}
